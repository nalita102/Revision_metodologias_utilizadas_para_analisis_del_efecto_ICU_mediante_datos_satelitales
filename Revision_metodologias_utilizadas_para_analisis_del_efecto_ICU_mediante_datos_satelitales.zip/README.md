# MGITG Articulo
 Esta es la pantilla para los articulos del cuaderno de la Maestría en Gestión de la Información y Tecnologías Geoespaciales (MGITG), ISBN: 2711-3558 (En línea)
